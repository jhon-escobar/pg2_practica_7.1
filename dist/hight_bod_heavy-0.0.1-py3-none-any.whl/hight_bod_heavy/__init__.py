from .hight_bod_heavy import CalculadoraIMC, CalculadoraGrasaCorporal, CalculadoraMasaMuscular

__all__ = [
    'CalculadoraIMC',
    'CalculadoraGrasaCorporal',
    'CalculadoraMasaMuscular'
]